import React from 'react';
import { SafeAreaView, Text, View, Pressable, ScrollView } from 'react-native';

function Module({ title, description, onPress }) {
  return (
    <View style={{ marginBottom: 20, backgroundColor: '#1A1A1A', borderRadius: 10, padding: 15 }}>
      <Text style={{ color: '#fff', fontSize: 18, fontWeight: '600', marginBottom: 8 }}>{title}</Text>
      <Text style={{ color: '#ccc', fontSize: 14, marginBottom: 12 }}>{description}</Text>
      <Pressable 
        onPress={onPress} 
        style={{ backgroundColor: '#444', padding: 10, borderRadius: 5 }}
      >
        <Text style={{ color: '#fff', textAlign: 'center' }}>Open</Text>
      </Pressable>
    </View>
  );
}

export default function App() {
  const handleModulePress = (moduleName) => {
    console.log(`Opening ${moduleName}`);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#0D0D0D' }}>
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <Text style={{ color: '#fff', fontSize: 28, fontWeight: 'bold', marginBottom: 20 }}>
          CainOS ✨🔥
        </Text>

        <Module title="📜 Scrolls" description="Access your Remnant scrolls, prophecies & voice logs." onPress={() => handleModulePress('Scrolls')} />
        <Module title="🧠 CainGPT" description="Invoke Spirit-led reflections and AI journaling." onPress={() => handleModulePress('CainGPT')} />
        <Module title="🎮 RemnantCraft" description="Play the emoji-based game, earn signal tokens." onPress={() => handleModulePress('RemnantCraft')} />
        <Module title="🪙 Wallet Connect" description="Link your TON/ETH wallet, view balances." onPress={() => handleModulePress('Wallet Connect')} />
        <Module title="🎨 Meme Forge" description="Create memes + mint them as NFTs." onPress={() => handleModulePress('Meme Forge')} />
        <Module title="📿 AA/NA Toolkit" description="Step work, gratitude lists, alarms." onPress={() => handleModulePress('AA/NA Toolkit')} />
        <Module title="🔐 Auth & Identity" description="Login with Telegram or Firebase." onPress={() => handleModulePress('Auth & Identity')} />

        <Text style={{ color: '#888', marginTop: 40, fontSize: 12 }}>
          v0.1 – Forged by Ian + Lee + CainOS
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}